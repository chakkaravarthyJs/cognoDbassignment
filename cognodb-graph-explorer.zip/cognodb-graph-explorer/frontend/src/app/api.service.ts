import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Developer {
  name: string;
  experience: number;
}
export interface Skill {
  name: string;
  category: string;
}
export interface Project {
  name: string;
  description: string;
}
export interface Recommendation {
  role: string;
  matchingSkills: string[];
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:3000/api';

  getStats(): Observable<any> { return this.http.get(`${this.baseUrl}/developers/stats`); }
  getDevelopers(): Observable<any> { return this.http.get(`${this.baseUrl}/developers`); }
  getDeveloper(name: string): Observable<any> { return this.http.get(`${this.baseUrl}/developers/${encodeURIComponent(name)}`); }
  getSkills(name: string): Observable<any> { return this.http.get(`${this.baseUrl}/developers/${encodeURIComponent(name)}/skills`); }
  getProjects(name: string): Observable<any> { return this.http.get(`${this.baseUrl}/developers/${encodeURIComponent(name)}/projects`); }
  getRecommendations(name: string): Observable<any> { return this.http.get(`${this.baseUrl}/developers/${encodeURIComponent(name)}/recommendations`); }
  getGraph(name: string): Observable<any> { return this.http.get(`${this.baseUrl}/developers/${encodeURIComponent(name)}/graph`); }
}
