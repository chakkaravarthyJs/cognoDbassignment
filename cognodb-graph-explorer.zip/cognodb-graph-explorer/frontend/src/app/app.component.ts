import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import cytoscape from 'cytoscape';
import { ApiService, Developer, Skill, Project, Recommendation } from './api.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  private api = inject(ApiService);

  developers: Developer[] = [];
  skills: Skill[] = [];
  projects: Project[] = [];
  recommendations: Recommendation[] = [];
  stats: any = {};
  selectedName = '';
  selectedDeveloper: Developer | null = null;
  loading = true;
  error = '';
  graphLoading = false;

  ngOnInit(): void {
    this.loadInitial();
  }

  loadInitial(): void {
    this.loading = true;
    this.error = '';
    this.api.getStats().subscribe({
      next: r => this.stats = r.data,
      error: () => this.error = 'Unable to connect to CognoDB. Check your backend and environment variables.'
    });
    this.api.getDevelopers().subscribe({
      next: r => {
        this.developers = r.data;
        if (this.developers.length) {
          this.selectedName = this.developers[0].name;
          this.selectDeveloper();
        }
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load developers from CognoDB.';
        this.loading = false;
      }
    });
  }

  selectDeveloper(): void {
    if (!this.selectedName) return;
    this.loading = true;
    this.error = '';
    this.api.getDeveloper(this.selectedName).subscribe({
      next: r => this.selectedDeveloper = r.data,
      error: () => this.error = 'Developer not found.'
    });
    this.api.getSkills(this.selectedName).subscribe({
      next: r => this.skills = r.data,
      error: () => this.skills = []
    });
    this.api.getProjects(this.selectedName).subscribe({
      next: r => this.projects = r.data,
      error: () => this.projects = []
    });
    this.api.getRecommendations(this.selectedName).subscribe({
      next: r => {
        this.recommendations = r.data;
        this.loading = false;
      },
      error: () => {
        this.recommendations = [];
        this.loading = false;
      }
    });
  }

  openGraph(): void {
    this.graphLoading = true;
    this.api.getGraph(this.selectedName).subscribe({
      next: r => {
        this.renderGraph(r.data);
        this.graphLoading = false;
      },
      error: () => {
        this.graphLoading = false;
        this.error = 'Unable to load graph visualization.';
      }
    });
  }

  renderGraph(data: any): void {
    const elements: any[] = [
      ...data.nodes.map((n: any) => ({
        data: {
          id: n.id,
          label: n.properties.name ?? n.properties.title ?? n.label,
          type: n.label
        }
      })),
      ...data.relationships.map((r: any) => ({
        data: {
          id: r.id,
          source: r.source,
          target: r.target,
          label: r.type
        }
      }))
    ];

    setTimeout(() => {
      const container = document.getElementById('graph');
      if (!container) return;

      cytoscape({
        container,
        elements,
        layout: { name: 'cose', animate: true },
        style: [
          {
            selector: 'node',
            style: {
              'label': 'data(label)',
              'background-color': '#536dfe',
              'color': '#172033',
              'text-valign': 'bottom',
              'text-margin-y': 8,
              'font-size': 12,
              'width': 34,
              'height': 34
            }
          },
          {
            selector: 'edge',
            style: {
              'label': 'data(label)',
              'curve-style': 'bezier',
              'target-arrow-shape': 'triangle',
              'line-color': '#b7bfd4',
              'target-arrow-color': '#b7bfd4',
              'font-size': 8
            }
          }
        ]
      });
    });
  }
}
