const { driver } = require('../src/config/database');

async function seed() {
  const session = driver.session();
  try {
    await session.run('MATCH (n) DETACH DELETE n');

    await session.run(`
      CREATE
      (angular:Skill {name:'Angular', category:'Frontend'}),
      (typescript:Skill {name:'TypeScript', category:'Language'}),
      (javascript:Skill {name:'JavaScript', category:'Language'}),
      (node:Skill {name:'Node.js', category:'Backend'}),
      (neo4j:Skill {name:'Graph Database', category:'Database'}),
      (spring:Skill {name:'Spring Boot', category:'Backend'}),

      (frontend:JobRole {title:'Frontend Developer'}),
      (fullstack:JobRole {title:'Full Stack Developer'}),
      (backend:JobRole {title:'Backend Developer'}),

      (yorosis:Company {name:'Yorosis Technologies'}),
      (project1:Project {name:'YoroFlow', description:'Workflow automation platform'}),
      (project2:Project {name:'Analytics Dashboard', description:'Interactive reporting dashboard'}),

      (chakkaravarthy:Developer {name:'Chakkaravarthy', experience:2}),
      (arun:Developer {name:'Arun', experience:3}),
      (priya:Developer {name:'Priya', experience:2}),
      (karthik:Developer {name:'Karthik', experience:4})

      CREATE
      (chakkaravarthy)-[:HAS_SKILL]->(angular),
      (chakkaravarthy)-[:HAS_SKILL]->(typescript),
      (chakkaravarthy)-[:HAS_SKILL]->(javascript),
      (chakkaravarthy)-[:HAS_SKILL]->(node),
      (chakkaravarthy)-[:HAS_SKILL]->(neo4j),
      (chakkaravarthy)-[:WORKED_ON]->(project1),
      (chakkaravarthy)-[:INTERESTED_IN]->(fullstack),

      (arun)-[:HAS_SKILL]->(angular),
      (arun)-[:HAS_SKILL]->(typescript),
      (arun)-[:HAS_SKILL]->(spring),
      (arun)-[:WORKED_ON]->(project1),

      (priya)-[:HAS_SKILL]->(javascript),
      (priya)-[:HAS_SKILL]->(node),
      (priya)-[:HAS_SKILL]->(neo4j),
      (priya)-[:WORKED_ON]->(project2),

      (karthik)-[:HAS_SKILL]->(spring),
      (karthik)-[:HAS_SKILL]->(node),
      (karthik)-[:WORKED_ON]->(project2),

      (project1)-[:BELONGS_TO]->(yorosis),
      (project2)-[:BELONGS_TO]->(yorosis),

      (project1)-[:USES_SKILL]->(angular),
      (project1)-[:USES_SKILL]->(typescript),
      (project1)-[:USES_SKILL]->(javascript),
      (project2)-[:USES_SKILL]->(javascript),
      (project2)-[:USES_SKILL]->(node),
      (project2)-[:USES_SKILL]->(neo4j),

      (frontend)-[:REQUIRES_SKILL]->(angular),
      (frontend)-[:REQUIRES_SKILL]->(typescript),
      (frontend)-[:REQUIRES_SKILL]->(javascript),

      (fullstack)-[:REQUIRES_SKILL]->(angular),
      (fullstack)-[:REQUIRES_SKILL]->(typescript),
      (fullstack)-[:REQUIRES_SKILL]->(node),
      (fullstack)-[:REQUIRES_SKILL]->(neo4j),

      (backend)-[:REQUIRES_SKILL]->(node),
      (backend)-[:REQUIRES_SKILL]->(spring)
    `);

    console.log('CognoDB seed completed successfully.');
  } catch (error) {
    console.error('Seed failed:', error.message);
    process.exitCode = 1;
  } finally {
    await session.close();
    await driver.close();
  }
}
seed();
