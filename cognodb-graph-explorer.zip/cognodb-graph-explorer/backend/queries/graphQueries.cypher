// Developer skills
MATCH (d:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)
RETURN s ORDER BY s.name;

// Multi-hop: developer -> skill -> project
MATCH (d:Developer {name: $name})
      -[:HAS_SKILL]->(s:Skill)
      <-[:USES_SKILL]-(p:Project)
RETURN d.name AS developer, s.name AS skill, p.name AS project
ORDER BY p.name;

// Career recommendations
MATCH (d:Developer {name: $name})
      -[:HAS_SKILL]->(s:Skill)
      <-[:REQUIRES_SKILL]-(r:JobRole)
RETURN r.title AS role, collect(s.name) AS matchingSkills
ORDER BY size(matchingSkills) DESC;

// Shared skills
MATCH (a:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)<-[:HAS_SKILL]-(b:Developer)
WHERE a <> b
RETURN b.name AS developer, collect(s.name) AS sharedSkills
ORDER BY size(sharedSkills) DESC;
