const { driver } = require('../config/database');

async function runQuery(cypher, params = {}) {
  const session = driver.session();
  try {
    const result = await session.run(cypher, params);
    return result.records;
  } finally {
    await session.close();
  }
}

async function getStats() {
  const records = await runQuery(`
    CALL {
      MATCH (d:Developer) RETURN count(d) AS developers
    }
    CALL {
      MATCH (s:Skill) RETURN count(s) AS skills
    }
    CALL {
      MATCH (p:Project) RETURN count(p) AS projects
    }
    CALL {
      MATCH (c:Company) RETURN count(c) AS companies
    }
    CALL {
      MATCH (r:JobRole) RETURN count(r) AS jobRoles
    }
    RETURN developers, skills, projects, companies, jobRoles
  `);
  const r = records[0];
  return {
    developers: r.get('developers').toNumber(),
    skills: r.get('skills').toNumber(),
    projects: r.get('projects').toNumber(),
    companies: r.get('companies').toNumber(),
    jobRoles: r.get('jobRoles').toNumber()
  };
}

async function getDevelopers() {
  const records = await runQuery(`
    MATCH (d:Developer)
    RETURN d
    ORDER BY d.name
  `);
  return records.map(r => r.get('d').properties);
}

async function getDeveloper(name) {
  const records = await runQuery(`
    MATCH (d:Developer {name: $name})
    RETURN d
  `, { name });
  return records.length ? records[0].get('d').properties : null;
}

async function getDeveloperSkills(name) {
  const records = await runQuery(`
    MATCH (d:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)
    RETURN s
    ORDER BY s.name
  `, { name });
  return records.map(r => r.get('s').properties);
}

async function getDeveloperProjects(name) {
  const records = await runQuery(`
    MATCH (d:Developer {name: $name})-[:WORKED_ON]->(p:Project)
    RETURN p
    ORDER BY p.name
  `, { name });
  return records.map(r => r.get('p').properties);
}

async function getRecommendations(name) {
  const records = await runQuery(`
    MATCH (d:Developer {name: $name})
          -[:HAS_SKILL]->(s:Skill)
          <-[:REQUIRES_SKILL]-(r:JobRole)
    RETURN r.title AS role, collect(s.name) AS matchingSkills
    ORDER BY size(matchingSkills) DESC
  `, { name });
  return records.map(r => ({
    role: r.get('role'),
    matchingSkills: r.get('matchingSkills')
  }));
}

async function getGraph(name) {
  const records = await runQuery(`
    MATCH (d:Developer {name: $name})
    OPTIONAL MATCH path = (d)-[*1..2]-(connected)
    WITH d, collect(DISTINCT connected) AS connected
    UNWIND [d] + connected AS n
    WITH collect(DISTINCT n) AS nodes
    UNWIND nodes AS n
    OPTIONAL MATCH (n)-[rel]-(m)
    WHERE m IN nodes
    RETURN nodes, collect(DISTINCT rel) AS relationships
  `, { name });

  if (!records.length) return { nodes: [], relationships: [] };

  const record = records[0];
  const nodes = record.get('nodes').map(node => ({
    id: String(node.elementId),
    label: node.labels[0] || 'Node',
    properties: node.properties
  }));

  const relationships = record.get('relationships')
    .filter(Boolean)
    .map(rel => ({
      id: String(rel.elementId),
      source: String(rel.startNodeElementId),
      target: String(rel.endNodeElementId),
      type: rel.type
    }));

  return { nodes, relationships };
}

module.exports = {
  getStats,
  getDevelopers,
  getDeveloper,
  getDeveloperSkills,
  getDeveloperProjects,
  getRecommendations,
  getGraph
};
