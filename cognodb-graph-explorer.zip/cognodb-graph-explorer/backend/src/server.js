const express = require('express');
const cors = require('cors');
const { verifyConnection } = require('./config/database');
const developerRoutes = require('./routes/developerRoutes');

require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', async (req, res) => {
  try {
    await verifyConnection();
    res.json({ status: 'UP', database: 'CONNECTED' });
  } catch (error) {
    res.status(503).json({ status: 'DOWN', database: 'UNAVAILABLE' });
  }
});

app.use('/api/developers', developerRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
