const express = require('express');
const controller = require('../controllers/developerController');

const router = express.Router();

router.get('/stats', controller.stats);
router.get('/', controller.list);
router.get('/:name', controller.detail);
router.get('/:name/skills', controller.skills);
router.get('/:name/projects', controller.projects);
router.get('/:name/recommendations', controller.recommendations);
router.get('/:name/graph', controller.graph);

module.exports = router;
