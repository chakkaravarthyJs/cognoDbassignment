const neo4j = require('neo4j-driver');
require('dotenv').config();

const required = ['COGNODB_URI', 'COGNODB_USERNAME', 'COGNODB_PASSWORD'];
for (const key of required) {
  if (!process.env[key]) {
    console.warn(`Missing environment variable: ${key}`);
  }
}

const driver = neo4j.driver(
  process.env.COGNODB_URI,
  neo4j.auth.basic(
    process.env.COGNODB_USERNAME,
    process.env.COGNODB_PASSWORD
  )
);

async function verifyConnection() {
  const session = driver.session();
  try {
    await session.run('RETURN 1 AS result');
    return true;
  } finally {
    await session.close();
  }
}

module.exports = { driver, verifyConnection };
