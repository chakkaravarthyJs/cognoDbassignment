const service = require('../services/graphService');

function handleError(res, error) {
  console.error(error);
  res.status(503).json({
    success: false,
    message: 'Graph database is currently unavailable.'
  });
}

async function stats(req, res) {
  try { res.json({ success: true, data: await service.getStats() }); }
  catch (e) { handleError(res, e); }
}

async function list(req, res) {
  try { res.json({ success: true, data: await service.getDevelopers() }); }
  catch (e) { handleError(res, e); }
}

async function detail(req, res) {
  try {
    const data = await service.getDeveloper(req.params.name);
    if (!data) return res.status(404).json({ success: false, message: 'Developer not found.' });
    res.json({ success: true, data });
  } catch (e) { handleError(res, e); }
}

async function skills(req, res) {
  try { res.json({ success: true, data: await service.getDeveloperSkills(req.params.name) }); }
  catch (e) { handleError(res, e); }
}

async function projects(req, res) {
  try { res.json({ success: true, data: await service.getDeveloperProjects(req.params.name) }); }
  catch (e) { handleError(res, e); }
}

async function recommendations(req, res) {
  try { res.json({ success: true, data: await service.getRecommendations(req.params.name) }); }
  catch (e) { handleError(res, e); }
}

async function graph(req, res) {
  try { res.json({ success: true, data: await service.getGraph(req.params.name) }); }
  catch (e) { handleError(res, e); }
}

module.exports = { stats, list, detail, skills, projects, recommendations, graph };
