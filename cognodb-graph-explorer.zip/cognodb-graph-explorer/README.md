# CognoDB Graph Explorer

A complete Angular + Node.js + CognoDB graph database take-home project.

## Use case

Developer Skill & Career Graph Explorer.

The app explores relationships between Developers, Skills, Projects, Companies and Job Roles.

## Why a graph database?

The interesting questions are relationship-oriented:

- Which projects are connected to a developer's skills?
- Which job roles match a developer's current skills?
- Which developers share skills?
- Which skills connect a developer to projects and roles?

These questions require multi-hop relationship traversal. A graph database represents those relationships directly and lets Cypher express the traversals naturally.

## Architecture

Angular -> Express REST API -> official Neo4j JavaScript driver -> CognoDB over Bolt.

## Data model

Developer -[:HAS_SKILL]-> Skill
Developer -[:WORKED_ON]-> Project
Developer -[:INTERESTED_IN]-> JobRole
Project -[:USES_SKILL]-> Skill
Project -[:BELONGS_TO]-> Company
JobRole -[:REQUIRES_SKILL]-> Skill

## Setup

1. Create a CognoDB free instance.
2. Copy the Bolt URI and generated password.
3. Copy `backend/.env.example` to `backend/.env`.
4. Fill in COGNODB_URI, COGNODB_USERNAME and COGNODB_PASSWORD.
5. From the root run:

   npm install
   npm run install-all
   npm run seed
   npm run dev

Frontend: http://localhost:4200
Backend: http://localhost:3000

## Environment

backend/.env:

COGNODB_URI=bolt+s://YOUR_INSTANCE_ID.databases.cognodb.cloud
COGNODB_USERNAME=cognodb
COGNODB_PASSWORD=YOUR_PASSWORD
PORT=3000

Never commit `.env`.

## Main Cypher queries

Developer skills:
MATCH (d:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)
RETURN s ORDER BY s.name

Multi-hop project traversal:
MATCH (d:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)<-[:USES_SKILL]-(p:Project)
RETURN d.name AS developer, s.name AS skill, p.name AS project

Career recommendation:
MATCH (d:Developer {name: $name})-[:HAS_SKILL]->(s:Skill)<-[:REQUIRES_SKILL]-(r:JobRole)
RETURN r.title AS role, collect(s.name) AS matchingSkills
ORDER BY size(matchingSkills) DESC

## Project structure

backend/
  src/config/database.js
  src/controllers/developerController.js
  src/routes/developerRoutes.js
  src/services/graphService.js
  src/server.js
  scripts/seed.js
  queries/graphQueries.cypher

frontend/
  src/app/

## Notes

The generated project is intentionally small and maintainable so you can explain each part during the interview.
